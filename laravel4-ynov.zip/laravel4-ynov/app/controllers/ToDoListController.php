<?php

class ToDoListController extends Controller{


	function addList(){

		$liste = new Liste;
		$liste->title = Input::get('title');
		$liste->list = Input::get('list');
		$liste->save();

		return View::make('add_list');
			
	}

	

}