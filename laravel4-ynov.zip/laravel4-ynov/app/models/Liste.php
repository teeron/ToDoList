<?php

class Liste extends Eloquent {
	protected $table = 'lists';
}