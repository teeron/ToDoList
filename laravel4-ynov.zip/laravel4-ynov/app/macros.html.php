<?php
HTML::macro('displayLists', function($name, $id){
	$lists = Liste::all();
	foreach ($lists as $list) {

		if($name !== null && $id == $list->id){
			echo '
					<div class="col-md-12" style="margin-top:0.5%;">
				     <div class="dropdown col-md-12">
				     <form method="post" class="open">
					   <button style="width:100%; text-align:left; background-color:#20e819;" class="col-md-8 btn btn-primary dropdown-toggle" type="button" data-toggle="dropdown">
					     <span style="color:#fff; font-weight:bold;" class="col-md-11">Modify</span>
					     <div class="col-md-1" style="text-align:center;"><span style="color:#fff;" class="caret"></span></div>
					   </button>
					   <input type="hidden" name="id" value="'.$list->id.'"/>
					   <ul class="dropdown-menu" style="margin:0; position:static; width:100%; text-align:center;">
					   	 <li><input style="border-top: 0px; border-left:0px; border-right: 0px; border-bottom: 1px #000 solid; font-size:20px; font-weight:bold; text-align:center;" type="text" name="title" value="'.$list->title.'"/><br><br>
					     <li><textarea style="width:100%; border:none; text-align:center;" name="list">'.$list->list.'</textarea></li>
					     <li><input style="background-color:#20e819; border:none; color:white; font-weight:bold; width:25%;" type="submit" value="Save" name="save"/></li>
					   </ul>
					   </form>
					 </div>
					</div>
				 ';
		}
		else{
			echo
			     '
			     	<div class="col-md-12" style="margin-top:0.5%;">
				     <div class="dropdown col-md-12">
					   <button style="width:100%; text-align:left; background-color:#f9f8e5;" class="col-md-8 btn btn-primary dropdown-toggle" type="button" data-toggle="dropdown">
					     <span style="color:#000;" class="col-md-11">Titre : '
					   		.$list->title.
					    '</span>
					     <div class="col-md-1" style="text-align:center;"><span style="color:#000;" class="caret"></span></div>
					   </button>
					   <ul class="dropdown-menu" style="margin:0; border-radius:0px 0px 4px 4px; position:static; width:100%; text-align:center;">
					   	 <form method="post">
					   	 	<input type="hidden" name="id" value="'.$list->id.'" />
					   	 	<li>
					   	 		<button name="modify" style="border:none; background-color:#fff;">
					   	 			<span style="color:#20e819;" class="glyphicon glyphicon-cog"></span>
					   	 		</button>
					   	 	</li>
					   		 <li>
					   	 		<button name="delete" style="border:none; background-color:#fff;">
					   	 			<span style="color:red;" class="glyphicon glyphicon-remove"></span>
					   	 		</button>
					   	 	</li>
					   	 	</form>
					     <li>'.$list->list.'</li>
					   </ul>
					 </div>
					</div>
				';
		}
	}
});

HTML::macro('left_sidebar', function()
{
    $builder = array();
    $menus = Config::get('config_sidebar.menus');
    $menusNames = array_keys($menus);
    $builder[] = '<ul class="sidebar-menu">
    				<li class="header" style="background-color:#f9f8e5; text-align:center;font-weight:bold; font-size:18px;">LIST ITEMS</li>';
    for($i = 0; $i < sizeof($menus); $i++)
    {
        $builder[] = sprintf('<li class="treeview"><a href="#" style="background-color: #e8d584;"><i style="color: #fff;" class="fa fa-link"></i> <span style="color: #fff;">%s</span>
           <span class="pull-right-container">
             <i style="color: #fff;" class="fa fa-angle-left pull-right"></i>
           </span>
         </a><ul class="treeview-menu" style="background-color:white;">', $menusNames[$i]);
        for($j = 0; $j < sizeof(array_values($menus)[$i]); $j++)
        {
          $infos = explode("->",array_values($menus)[$i][$j]);
            $builder[] = sprintf('<li style="border-bottom: 1px #000 solid;"><a style="color: #000;" href="%s">%s</a></li>',$infos[1], $infos[0]);
        }
        $builder[] = '</ul></li>';        
    }
    $builder[] = '</ul>';
    return join("\n", $builder);
});
 
HTML::macro('displayAddList', function(){

	echo
	'
	<div class="col-md-6 col-md-offset-3" style="background-color:#fff; border-radius:3px;box-shadow:0px 0px 10px -3px #000;">
		<form class="col-md-8 col-md-offset-2" method="post" style="margin-top:5%; margin-bottom:5%;">
			<label class="col-md-12">Titre : </label>
			<input class="col-md-12" type="text" name="title">
			<label class="col-md-12">Liste : </label>
			<textarea class="col-md-12" name="list"></textarea>
			<input class="col-md-12" type="submit" value="Add" style="background-color:#20e819; border:none; border-radius:4px; color:white; font-weight:bold; margin-top:2%;"/>
		</form>
	</div>
	';

});


?>
