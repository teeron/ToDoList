<h1>header</h1>
<?=$contenu?>
<hr>
<h1>footer</h1>