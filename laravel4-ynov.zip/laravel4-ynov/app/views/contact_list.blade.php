@extends('AdminLTE.layout')

@section('page-title')
	Display Lists
@stop

@section('content')

{{ HTML::displayLists($name, $id) }}

@stop