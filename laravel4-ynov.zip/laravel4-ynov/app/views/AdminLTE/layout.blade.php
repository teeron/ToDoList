<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>@yield('page-title','** page-title **')</title>
   <base href="{{ asset(Config::get('template.AdminLTEPublicURL')) }}/" >
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <link rel="stylesheet" href="{{ asset(Config::get('template.AdminLTEPublicURL')) }}/bootstrap/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.5.0/css/font-awesome.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/ionicons/2.0.1/css/ionicons.min.css">
  <link rel="stylesheet" href="{{ asset(Config::get('template.AdminLTEPublicURL')) }}/dist/css/AdminLTE.min.css">
  <link rel="stylesheet" href="{{ asset(Config::get('template.AdminLTEPublicURL')) }}/dist/css/skins/skin-{{ Config::get('template.skin','blue') }}.min.css">
</head>

<body class="hold-transition skin-{{ Config::get('template.skin','blue') }}  {{ Config::get('template.layout-options','sidebar-mini') }} ">
<div class="wrapper" style="background-color: #f9f8e5;">
  <nav class="navbar navbar-default" style="background-color: #e8d584; border-left: 0px; border-right: 0px; border-top: 0px; border-bottom: 1px #000 solid; border-radius: 0px;">
    <div class="container-fluid">
      <div class="navbar-header">
        <a class="navbar-brand" href="#">
          <img alt="TODOLIST" src="...">
        </a>
      </div>
    </div>
  </nav>

  <aside class="main-sidebar" style="position:fixed; top:52px; background-color: #f9f8e5;"> 
    <section class="sidebar">
		@include('AdminLTE.parts.sidebar')
    </section>
  </aside>
  <div class="content-wrapper" style="background-color: #fff;">
    <section class="content-header">
      <h1 style="text-align:center;text-decoration: underline;">@yield('page-title','** page-title **')</h1>
    </section>
    <section class="content container">
	@section('content')
	@show
    </section>
  </div>
  <footer class="main-footer">
    <div class="pull-right hidden-xs">
		@section('right-footer')
		Anything you want
		@show
    </div>
	{{ Config::get('template.copyright') }}
  </footer>
  <aside class="control-sidebar control-sidebar-dark">
    <ul class="nav nav-tabs nav-justified control-sidebar-tabs">
      <li class="active"><a href="#control-sidebar-home-tab" data-toggle="tab"><i class="fa fa-home"></i></a></li>
      <li><a href="#control-sidebar-settings-tab" data-toggle="tab"><i class="fa fa-gears"></i></a></li>
    </ul>
    <div class="tab-content">
      <div class="tab-pane active" id="control-sidebar-home-tab">
        <h3 class="control-sidebar-heading">Recent Activity</h3>
        <ul class="control-sidebar-menu">
          <li>
            <a href="javascript:;">
              <i class="menu-icon fa fa-birthday-cake bg-red"></i>
              <div class="menu-info">
                <h4 class="control-sidebar-subheading">Langdon's Birthday</h4>
                <p>Will be 23 on April 24th</p>
              </div>
            </a>
          </li>
        </ul>
        <h3 class="control-sidebar-heading">Tasks Progress</h3>
        <ul class="control-sidebar-menu">
          <li>
            <a href="javascript:;">
              <h4 class="control-sidebar-subheading">
                Custom Template Design
                <span class="pull-right-container">
                  <span class="label label-danger pull-right">70%</span>
                </span>
              </h4>
              <div class="progress progress-xxs">
                <div class="progress-bar progress-bar-danger" style="width: 70%"></div>
              </div>
            </a>
          </li>
        </ul>
      </div>
      <div class="tab-pane" id="control-sidebar-stats-tab">Stats Tab Content</div>
      <div class="tab-pane" id="control-sidebar-settings-tab">
        <form method="post">
          <h3 class="control-sidebar-heading">General Settings</h3>
          <div class="form-group">
            <label class="control-sidebar-subheading">
              Report panel usage
              <input type="checkbox" class="pull-right" checked>
            </label>
            <p>
              Some information about this general settings option
            </p>
          </div>
        </form>
      </div>
    </div>
  </aside>
  <div class="control-sidebar-bg"></div>
</div>

<script src="{{ asset(Config::get('template.AdminLTEPublicURL')) }}/plugins/jQuery/jquery-2.2.3.min.js"></script>
<script src="{{ asset(Config::get('template.AdminLTEPublicURL')) }}/bootstrap/js/bootstrap.min.js"></script>
<script src="{{ asset(Config::get('template.AdminLTEPublicURL')) }}/dist/js/app.min.js"></script>
</body>
</html>