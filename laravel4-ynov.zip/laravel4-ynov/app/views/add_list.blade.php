@extends('AdminLTE.layout')

@section('page-title')
	Add List
@stop

@section('content')
	{{ HTML::displayAddList() }}
@stop