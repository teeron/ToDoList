<?php
/************************** TEST MA VUE DISPLAY & ADD ***********************/ 
Route::get('display', function()
{
	return View::make('contact_list')->with('name', null)->with('id', null);;
});

Route::post('display', function(){
	$id = Input::get('id');

	if(Input::get('delete')!== null){
		$liste = Liste::find($id);
		$liste->delete();

		return View::make('contact_list')->with('name', null)->with('id', null);;
	}

	else if(Input::get('modify')!== null){
		return View::make('contact_list')->with('name', 'modify')->with('id', $id);
	}

	else if(Input::get('save')!==null){

		$liste = Liste::find($id);
		$liste->title = Input::get('title');
		$liste->list = Input::get('list');
		$liste->save();

		return View::make('contact_list')->with('name', null)->with('id', null);
	}
});

Route::get('addList', function(){
	return View::make('add_list');
});

Route::post('addList', 'ToDoListController@addList');


/****************************************************************************/ 









/********** TEST FORM *************/ 
Route::get('form1', function(){
	echo Form::open();
    echo Form::label('nom', 'Nom :');
    echo Form::text('nom'),'<br>';
    echo Form::label('ville', 'Ville :');
    echo Form::text('ville'),'<br>';
    echo Form::label('age', 'Age :');
    echo Form::text('age'),'<br>';
    echo Form::submit('Submit');
    echo Form::close();
});

Route::post('form1', function(){
	echo "<pre>";
	print_r(Input::all());
	
	echo "Sans le token, ni l'age<br>";
	print_r(Input::except('_token','age'));
	
	echo "Seulement nom et ville<br>";
	print_r(Input::only('nom','ville'));
});


/********** TEST UPLOAD *************/ 
Route::get('send-file', function(){
	echo Form::open(array( 'enctype' => 'multipart/form-data'));
    echo Form::file('fichier');
    echo Form::submit('Envoyer le fichier');
    echo Form::close();
});

Route::post('send-file', function(){
	if(!file_exists('uploads'))
		mkdir('uploads');
	Input::file('fichier')->move('uploads', 'mon_fichier.jpg');
	echo HTML::image('public/uploads/mon_fichier.jpg','mon fichier');
});

/********** VUES AVEC PARAMS *************/ 
Route::get('bonjour/{nom}', function($nom){
	return View::make('tests.bonjour')->with('nom', $nom);
});

/********** VUES NESTED AVEC PARAMS  *************/ 
Route::get('bonjour2/{nom}', function($nom){
	return View::make('tests.bonjour-nested')
		->nest('nested','tests.sous-vue')
		->with('nom',$nom);
});


/********** PAGES AVEC 404 *************/ 
Route::get('pages/{page}',function($page){
	$view_page = 'site.pages.'.$page;
	if(View::exists($view_page))
		return View::make('site.pages.template')->nest('contenu', $view_page);
	return App::abort('404');
});


Route::get('contacts', function(){
	$contacts = Contact::all();
	return View::make('contact')->with('contacts', $contacts);
	return View::make('contact', array('contacts'=>$contacts));
	return View::make('contact', compact('contacts'));
});
	
	/********** VUES CONTACTS *************/ 
Route::get('contact', function(){
	return View::make('contact');
});

	
Route::post('contact', function(){
	$inputs = Input::except('_token');
	$contact = new Contact;
	foreach($inputs as $k=>$v){
		$contact->$k = $v;
	}
	$contact->save();
});



/*Quarantaine*/

Route::get('test-sql', function(){
	// insertion d'un enregistrement
	DB::table('contacts')->insert(
		array(
			'firstname' => 'will',
			'lastname' => 'durand',
			'subject' => 'sujet du contact will',
			'message' => 'un message pour will'
		)
	);
	// insertion de plusieurs enregistrements
	DB::table('contacts')->insert(
		array(
			array(
				'firstname' => 'paul',
				'lastname' => 'lamotte',
				'subject' => 'sujet du contact pierre',
				'message' => 'un message pour pierre'
			),

			array(
				'firstname' => 'paul',
				'lastname' => 'sanchez',
				'subject' => 'sujet du contact paul',
				'message' => 'un message pour paul'
			)
		)
	);
	// select * from contacts
	$contacts = DB::table('contacts')->get();
	echo "<pre>";
	print_r($contacts);
	echo "</pre>";
	
	// select * from contacts where firstname = 'paul'
	$contacts = DB::table('contacts')->where('firstname','=','paul')->get();
	echo "<pre>";
	print_r($contacts);
	echo "</pre>";
	
	// récupération du 1er
	$contacts = DB::table('contacts')->where('firstname','=','paul')->first();
	echo "<pre>";
	print_r($contacts);
	echo "</pre>";
	
	// select firstname, lastname from contacts where firstname = 'paul'
	$contacts = DB::table('contacts')
		->select('firstname','lastname')
		->where('firstname','=','paul')
		->get();
	echo "<pre>";
	print_r($contacts);
	echo "</pre>";
	
	// select firstname, lastname from contacts where firstname = 'paul' or lastname = 'sanchez'
	$contacts = DB::table('contacts')
		->select('firstname','lastname')
		->where('firstname','=','paul')
		->orWhere('lastname','=','sanchez')
		->get();
	echo "<pre>";
	print_r($contacts);
	echo "</pre>";	
	
	// select * from contacts where  order by lastname desc
	$contacts = DB::table('contacts')
		->orderBy('lastname', 'desc')
		->get();
	echo "<pre>";
	print_r($contacts);
	echo "</pre>";
	
	// mise a jour
	DB::table('contacts')
		->where('firstname', '=', 'will')
		->update(
			array(
				'firstname' => 'will',
				'lastname' => 'johnson',
				'subject' => 'sujet du contact will johnson',
				'message' => 'un message pour will johnson'
			)
		);
	
	// suppression
	DB::table('contacts')
		->where('firstname', '=', 'will')
		->delete();
});

/*Quarantaine*/


/********** 404 *************/ 
App::missing(function($exception){
    return Response::make('Page Introuvable', 404);
});