<?php
return array(

	'menus' => [
        'TODOLIST' => ['Display Lists->/laravel4-ynov/index.php/display', 'Add List->/laravel4-ynov/index.php/addList'],
        ]

        
	
);