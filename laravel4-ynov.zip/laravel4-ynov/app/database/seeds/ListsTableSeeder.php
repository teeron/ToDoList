<?php

	class ListsTableSeeder extends Seeder {
	    public function run() {
	        DB::table('lists')->insert(
	            array(
	                array(
	                    'Title' => 'Liste de Courses',
	                    'List' => 'Huile<br>Savon<br>Pain<br>Dentifrice<br>Jus de fruit',
	                ),
	 
	                array(
	                    'Title' => 'Devoirs',
	                    'List' => 'Anglais : Exo 4 & 5 page 245.<br>Français Eval Dissertation(4h)',
	                ),
	            )
	        );
	    }
	}
?>